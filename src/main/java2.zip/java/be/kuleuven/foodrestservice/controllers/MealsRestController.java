package be.kuleuven.foodrestservice.controllers;

import be.kuleuven.foodrestservice.domain.Meal;
import be.kuleuven.foodrestservice.domain.MealsRepository;
import be.kuleuven.foodrestservice.exceptions.MealNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;
import be.kuleuven.foodrestservice.domain.Order;
import be.kuleuven.foodrestservice.domain.OrderConfirmation;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.http.ResponseEntity;


import java.util.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
public class MealsRestController {

    private final MealsRepository mealsRepository;

    @Autowired
    MealsRestController(MealsRepository mealsRepository) {
        this.mealsRepository = mealsRepository;
    }

    @GetMapping("/rest/meals/{id}")
    EntityModel<Meal> getMealById(@PathVariable String id) {
        Meal meal = mealsRepository.findMeal(id).orElseThrow(() -> new MealNotFoundException(id));

        return mealToEntityModel(id, meal);
    }

    @GetMapping("/rest/meals")
    CollectionModel<EntityModel<Meal>> getMeals() {
        Collection<Meal> meals = mealsRepository.getAllMeal();

        List<EntityModel<Meal>> mealEntityModels = new ArrayList<>();
        for (Meal m : meals) {
            EntityModel<Meal> em = mealToEntityModel(m.getId(), m);
            mealEntityModels.add(em);
        }
        return CollectionModel.of(mealEntityModels,
                linkTo(methodOn(MealsRestController.class).getMeals()).withSelfRel());
    }

    private EntityModel<Meal> mealToEntityModel(String id, Meal meal) {
        return EntityModel.of(meal,
                linkTo(methodOn(MealsRestController.class).getMealById(id)).withSelfRel(),
                linkTo(methodOn(MealsRestController.class).getMeals()).withRel("rest/meals"));
    }

    @GetMapping("/rest/meals/cheapest")
    public EntityModel<Meal> getCheapestMeal() {
        Meal meal = mealsRepository.getCheapestMeal();
        return EntityModel.of(meal,
                linkTo(methodOn(MealsRestController.class).getCheapestMeal()).withSelfRel(),
                linkTo(methodOn(MealsRestController.class).getMeals()).withRel("rest/meals"));
    }

    @GetMapping("/rest/meals/largest")
    public EntityModel<Meal> getLargestMeal() {
        Meal meal = mealsRepository.getLargestMeal();
        return EntityModel.of(meal,
                linkTo(methodOn(MealsRestController.class).getLargestMeal()).withSelfRel(),
                linkTo(methodOn(MealsRestController.class).getMeals()).withRel("rest/meals"));
    }

    @PostMapping("/rest/orders")
    public EntityModel<OrderConfirmation> placeOrder(@RequestBody Order order) {
        OrderConfirmation confirmation = mealsRepository.addOrder(order);

        return EntityModel.of(confirmation,
                linkTo(methodOn(MealsRestController.class).placeOrder(order)).withSelfRel(),
                linkTo(methodOn(MealsRestController.class).getMeals()).withRel("meals"),
                linkTo(methodOn(MealsRestController.class).getCheapestMeal()).withRel("cheapestMeal"),
                linkTo(methodOn(MealsRestController.class).getLargestMeal()).withRel("largestMeal"));
    }

}
