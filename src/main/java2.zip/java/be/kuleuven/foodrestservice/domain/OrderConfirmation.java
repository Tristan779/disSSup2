package be.kuleuven.foodrestservice.domain;
import java.util.List;

public class OrderConfirmation {
    private String confirmationMessage;
    private List<String> orderedMealNames;

    public OrderConfirmation(String message, List<String> mealNames) {
        this.confirmationMessage = message;
        this.orderedMealNames = mealNames;
    }

    // Getters and setters
    public String getConfirmationMessage() {
        return confirmationMessage;
    }

    public void setConfirmationMessage(String confirmationMessage) {
        this.confirmationMessage = confirmationMessage;
    }

    public List<String> getOrderedMealNames() {
        return orderedMealNames;
    }

    public void setOrderedMealNames(List<String> orderedMealNames) {
        this.orderedMealNames = orderedMealNames;
    }
}